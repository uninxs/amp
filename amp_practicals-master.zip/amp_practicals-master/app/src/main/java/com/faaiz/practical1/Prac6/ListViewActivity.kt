package com.faaiz.practical1.Prac6

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import com.faaiz.practical1.R

class ListViewActivity : AppCompatActivity() {

    lateinit var gamesList: ListView
    lateinit var selectedGame: TextView
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_view)
        gamesList = findViewById(R.id.gamesList)
        selectedGame = findViewById(R.id.selectedGame)
        val games: Array<String> = arrayOf("PUBG", "Fortnite", "Valorant", "BGMI",
            "GTA V1", "Red Dead Redemption", "Minecraft", "CS GO", "GTA Vice City", "Asphalt8")
                    gamesList.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,
            games)
        gamesList.setOnItemClickListener { adapterView, view, i, l ->
            selectedGame.text = games.get(i)
        }
    }

}