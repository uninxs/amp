package com.faaiz.practical1.prac13

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.core.app.ActivityCompat
import com.faaiz.practical1.R

class TelephoneApiActivity : AppCompatActivity() {
    lateinit var callBtn: Button
    lateinit var phoneET: EditText
    val REQUEST_CODE = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_telephone_api)

        callBtn=findViewById(R.id.callBtn)
        phoneET=findViewById(R.id.phontET)

        callBtn.setOnClickListener{
            if(ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) !=
                PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                    arrayOf(Manifest.permission.CALL_PHONE), REQUEST_CODE)
            } else makeCall()
        }
    }

    private fun makeCall(){
        val intent = Intent(Intent.ACTION_CALL)
        intent.data = Uri.parse("tel:" + phoneET.text.toString())
        startActivity(intent)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions:
    Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode==REQUEST_CODE) makeCall()
    }
}