package com.faaiz.practical1.prac10

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.FrameLayout
import androidx.fragment.app.Fragment
import com.faaiz.practical1.R

class FragmentsHostActivity : AppCompatActivity() {

    lateinit var frameLayout : FrameLayout
    lateinit var btn1 : Button
    lateinit var btn2 : Button
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fragments_host)

        frameLayout = findViewById(R.id.frameLayout)
        btn1 = findViewById(R.id.btn1)
        btn2 = findViewById(R.id.btn2)

        loadFragment(Fragment1())

        btn1.setOnClickListener{
            loadFragment(Fragment1())
        }
        btn2.setOnClickListener{
            loadFragment(Fragment2())
        }


    }

    var i = 0;
    private fun loadFragment(fragment : Fragment) {
        val ft = supportFragmentManager.beginTransaction()
        if(i == 0){
            ft.add(R.id.frameLayout, fragment)
            i++
        }else{
            ft.replace(R.id.frameLayout, fragment)
        }
        ft.commit()
    }
}