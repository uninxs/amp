package com.faaiz.practical1.prac14

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import com.faaiz.practical1.R

class ImplicitIntentActivity : AppCompatActivity() {

    lateinit var dataEt : EditText
    lateinit var btn : Button
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_implicit_intent)

        dataEt = findViewById(R.id.dataET)
        btn = findViewById(R.id.button)

        btn.setOnClickListener{
            val intent = Intent(Intent.ACTION_SEND)
            intent.putExtra(Intent.EXTRA_TEXT, dataEt.text.toString())
            intent.setType("text/plain")

            if(intent.resolveActivity(packageManager) != null){
                startActivity(intent)
            }

        }

    }
}