package com.faaiz.practical1.Prac3

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.faaiz.practical1.R

class NotificationsActivity : AppCompatActivity() {

    lateinit var clickableBtn : Button
    lateinit var nonClickableBtn : Button

    private val CHANNEL_ID = "my_channel"
    private val NOTIFICATION_ID_CLICKABLE = 2
    private val NOTIFICATION_ID_NON_CLICKABLE = 1

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notifications)

        clickableBtn = findViewById(R.id.clickableNotificationBtn)
        nonClickableBtn = findViewById(R.id.nonClickableNotificationBtn)

        createNotificationChannel()

        clickableBtn.setOnClickListener{
            showClickableNotification()
        }

        nonClickableBtn.setOnClickListener{
            showNonClickableNotification()
        }
    }

    private fun showClickableNotification(){
        val intent = Intent(this, NotificationsActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        val pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)

        val builder = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_background)
            .setAutoCancel(true)
            .setContentTitle("Clickable Notification")
            .setContentText("from practical 3")
            .setContentIntent(pendingIntent)

        val notificationManager : NotificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID_CLICKABLE, builder.build())
    }

    private fun showNonClickableNotification(){
        val builder = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_background)
            .setAutoCancel(true)
            .setContentTitle("Non Clickable Notification")
            .setContentText("dummy text")

        val notificationManager : NotificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID_NON_CLICKABLE, builder.build())
    }

    private fun createNotificationChannel(){
        val name = "Practical 3"
        val desc = "Create notification"
        val importance = NotificationManager.IMPORTANCE_DEFAULT
        val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
            description = desc
        }
        val notificationManager : NotificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.createNotificationChannel(channel)
    }
}