package com.faaiz.practical1.prac5

import android.annotation.SuppressLint
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkInfo
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import com.faaiz.practical1.R

class BroadcastReceiverActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_broadcast_receiver)

        val info = findViewById<TextView>(R.id.tvInfo)

        val manager : ConnectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkInfo : NetworkInfo?  = manager.activeNetworkInfo

        if(networkInfo != null && networkInfo.isConnected){
            if(networkInfo.type == ConnectivityManager.TYPE_MOBILE){
                info.text = "Connected to cellular"
            }
            if(networkInfo.type == ConnectivityManager.TYPE_WIFI){
                info.text = "Connected to wifi"
            }
        }else{
            info.text = "You are offline"
        }

    }

}