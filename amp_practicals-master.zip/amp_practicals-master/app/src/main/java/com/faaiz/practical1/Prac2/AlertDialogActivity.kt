package com.faaiz.practical1.Prac2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.faaiz.practical1.R

class AlertDialogActivity : AppCompatActivity() {

    lateinit var btn : Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alert_dialog)

        btn = findViewById(R.id.btn)

        btn.setOnClickListener{
            val alertDialog = AlertDialog.Builder(this)
            alertDialog.setTitle("Alert!")
            alertDialog.setMessage("This is a dummy dialog")

            alertDialog.setPositiveButton("Yes"){
                dialogInterface, which -> Toast.makeText(this, "Yes clicked", Toast.LENGTH_SHORT).show()
            }

            alertDialog.setNegativeButton("No"){
                dialogInterface, which -> Toast.makeText(this, "No clicked", Toast.LENGTH_SHORT).show()
            }

            alertDialog.setNeutralButton("Cancel"){
                    dialogInterface, which -> Toast.makeText(this, "Cancel clicked", Toast.LENGTH_SHORT).show()
            }

            alertDialog.create()
            alertDialog.show()
        }

    }
}