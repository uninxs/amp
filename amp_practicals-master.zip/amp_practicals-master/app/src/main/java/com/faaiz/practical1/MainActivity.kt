package com.faaiz.practical1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.Toast
import com.faaiz.practical1.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding : ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.proceedBtn.setOnClickListener(View.OnClickListener {
            if(!binding.editText.text.trim().isEmpty()){
                val intent = Intent(this, MainActivity2::class.java)
                intent.putExtra("name" , binding.editText.text.toString())
                startActivity(intent)
            }else{
                Toast.makeText(applicationContext, "Please Enter a name", Toast.LENGTH_SHORT)
            }
        })
    }
}