package com.faaiz.practical1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import androidx.core.text.set

class MainActivity2 : AppCompatActivity() {

    lateinit var tvName : TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        tvName = findViewById(R.id.textView)

        val name = intent.getStringExtra("name")
        tvName.text = name
    }
}