package com.faaiz.practical1.prac12

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.faaiz.practical1.R

class AlertFragmentActivity : AppCompatActivity() {
    lateinit var btn : Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alert_fragment)

        btn = findViewById(R.id.callfrag)

        btn.setOnClickListener{
            val fm = supportFragmentManager
            val myFragment = AlertDialogFragment()
            myFragment.show(fm, "Login Page")
        }
    }
}