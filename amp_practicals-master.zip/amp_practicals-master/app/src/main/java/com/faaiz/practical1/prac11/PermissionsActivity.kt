package com.faaiz.practical1.prac11

import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import com.faaiz.practical1.R

class PermissionsActivity : AppCompatActivity() {

    lateinit var cameraBtn: Button
    lateinit var calendarBtn: Button
    lateinit var contactsBtn: Button

    private val CAMERA_REQUEST_CODE = 101
    private val CALENDAR_REQUEST_CODE = 102
    private val CONTACTS_REQUEST_CODE = 103

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_permissions)

        cameraBtn = findViewById(R.id.cameraButton)
        calendarBtn = findViewById(R.id.calendarButton)
        contactsBtn = findViewById(R.id.contactsButton)


        cameraBtn.setOnClickListener{
            checkAndRequestPermission("Camera", android.Manifest.permission.CAMERA, CAMERA_REQUEST_CODE)
        }

        calendarBtn.setOnClickListener{
            checkAndRequestPermission("Calendar", android.Manifest.permission.READ_CALENDAR, CALENDAR_REQUEST_CODE)
        }

        contactsBtn.setOnClickListener{
            checkAndRequestPermission("Contacts", android.Manifest.permission.READ_CONTACTS, CONTACTS_REQUEST_CODE)
        }

    }

    private fun checkAndRequestPermission(whichButton : String, whichPermission : String, requestCode : Int){
        if(checkSelfPermission(whichPermission) != PackageManager.PERMISSION_GRANTED){
            Toast.makeText(this, "$whichButton Button Clicked", Toast.LENGTH_SHORT).show()
            requestPermissions(arrayOf(whichPermission), requestCode)
        }else{
            Toast.makeText(this, "You already have $whichButton access", Toast.LENGTH_SHORT).show()

        }
    }
}