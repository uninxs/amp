package com.faaiz.practical1.prac7

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.faaiz.practical1.R

class ChangeContentActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_change_content)
    }
}