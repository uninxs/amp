package com.faaiz.practical1.prac8

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.widget.Toolbar
import com.faaiz.practical1.R

class MenuSubmenuActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu_submenu)

        val toolbar = findViewById<Toolbar>(R.id.my_toolbar)
        setSupportActionBar(toolbar)


    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val toastMessage : String

        when(item.itemId){
            R.id.about -> {
                toastMessage = "About Selected"
            }
            R.id.version -> {
                toastMessage = "Version Selected"
            }
            R.id.license -> {
                toastMessage = "License Selected"
            }
            else -> return super.onOptionsItemSelected(item)
        }
        Toast.makeText(this, toastMessage, Toast.LENGTH_SHORT).show()
        return true
    }
}